import numpy as np
import os,shutil,subprocess,sys

def writeUnit5(path:str,teff:float,log_g:float,species_dict:dict,is_lte:bool):
    """
    Helper function that writes the unit 5 files for TLUSTY model runs.
    """

    # First block: temp, gravity, LTE/LTGRAY flags, flag file, frequency points
    b = 'T' if is_lte else 'F'

    f = open(path+'/fort.5','w')
    f.write(str(int(teff))+'\t'+np.format_float_positional(log_g,precision=3)+'\t! T_eff, log(g)\n')
    f.write(f'{b}\t{b}       ! LTE, LTGRAY\n')
    f.write('\'cwd2.flag\' ! Add\'l params\n')
    f.write('200        ! frequency points(?)\n')

    # Second block: species, modes of computation, and abundances
    num_exp = len(species_dict.keys())
    f.write(str(num_exp)+'\t\t! atoms\n')
    f.write('* mode abn modpf\n')
    for key in species_dict.keys():
        # if key=='h':continue
        f.write(f'  {species_dict[key]['mode']}   {species_dict[key]['abn']}   0   ! {key}\n')
    
    # Third block: Explicit ions
    f.write('*\n* explicit ions\n*\n')
    f.write('* iat iz nlevs ilast ilvlin nonstd typion file\n*\n')

    # Include files for relevant species. Do not set mode=2 to any species but these!!!
    if species_dict['h']['mode']==2:
        f.write("""  1   0   16   0   0     0   ' H 1' './data/h1s16.dat'
  1   1   1    1   0     0   ' H 2' ' '\n""")
    if species_dict['he']['mode']==2:
        f.write("""  2   0   24   0   0     0   'He 1' './data/he1.dat'
  2   1   20   0   0     0   'He 2' './data/he2.dat'
  2   2   1    1   0     0   'He 3' ' '\n""")
    if species_dict['c']['mode']==2:
        f.write("""  6   0   40   0   0     0   ' C 1' './data/c1.dat'
  6   1   22   0   0     0   ' C 2' './data/c2.dat'
  6   2   46   0   0     0   ' C 3' './data/c3_34+12lev.dat'
  6   3   25   0   0     0   ' C 4' './data/c4.dat'
  6   4   1    1   0     0   ' C 5' ' '\n""")
    if species_dict['n']['mode']==2:
        f.write("""  7   0   34   0   0     0   ' N 1' './data/n1.dat'
  7   1   42   0   0     0   ' N 2' './data/n2_32+10lev.dat'
  7   2   32   0   0     0   ' N 3' './data/n3.dat'
  7   3   48   0   0     0   ' N 4' './data/n4_34+14lev.dat'
  7   4   16   0   0     0   ' N 5' './data/n5.dat'
  7   5   1    1   0     0   ' N 6' ' '\n""")
    if species_dict['o']['mode']==2:
        f.write("""  8   0   33   0   0     0   ' O 1' './data/o1_23+10lev.dat'
  8   1   48   0   0     0   ' O 2' './data/o2_36+12lev.dat'
  8   2   41   0   0     0   ' O 3' './data/o3_28+13lev.dat'
  8   3   39   0   0     0   ' O 4' './data/o4.dat'
  8   4   6    0   0     0   ' O 5' './data/o5.dat'
  8   5   1    1   0     0   ' O 6' ' '\n""")
    if species_dict['ne']['mode']==2:
        f.write("""  10  0   35   0   0     0   'Ne 1' './data/ne1_23+12lev.dat'
  10  1   32   0   0     0   'Ne 2' './data/ne2_23+9lev.dat'
  10  2   34   0   0     0   'Ne 3' './data/ne3_22+12lev.dat'
  10  3   12   0   0     0   'Ne 4' './data/ne4.dat'
  10  4   1    1   0     0   'Ne 5' ' '\n""")
    if species_dict['mg']['mode']==2:
        f.write("""  12  1   25   0   0     0   'Mg 2' './data/mg2.dat'
  12  2   1    1   0     0   'Mg 3' ' '\n""")
    if species_dict['al']['mode']==2:
        f.write("""  13  1   29   0   0     0   'Al 2' './data/al2_20+9lev.dat'
  13  2   23   0   0     0   'Al 3' './data/al3_19+4lev.dat'
  13  3   1    1   0     0   'Al 4' ' '\n""")
    if species_dict['si']['mode']==2:
        f.write("""  14  1   40   0   0     0   'Si 2' './data/si2_36+4lev.dat'
  14  2   30   0   0     0   'Si 3' './data/si3.dat'
  14  3   23   0   0     0   'Si 4' './data/si4.dat'
  14  4   1    1   0     0   'Si 5' ' '\n""")
    if species_dict['s']['mode']==2:
        f.write("""  16  1   33   0   0     0   ' S 2' 'data/s2_23+10lev.dat'
  16  2   41   0   0     0   ' S 3' './data/s3_29+12lev.dat'
  16  3   38   0   0     0   ' S 4' './data/s4_33+5lev.dat'
  16  4   25   0   0     0   ' S 5' './data/s5_20+5lev.dat'
  16  5   1    1   0     0   ' S 6' ' '\n""")
    if species_dict['fe']['mode']==2:
        f.write("""  26  1   36   0   0     -1  'Fe 2' './data/fe2va.dat'
   0  0                             './data/gf2601.gam'
                                    './data/gf2601.lin'
                                    './data/fe2p_14+11lev.rap'
  26  2   50   0   0     -1  'Fe 3' './data/fe3va.dat'
   0  0                             './data/gf2602.gam'
                                    './data/gf2602.lin'
                                    './data/fe3p_22+7lev.rap'
  26  3   43   0   0     -1  'Fe 4' './data/fe4va.dat'
   0  0                             './data/gf2603.gam'
                                    './data/gf2603.lin'
                                    './data/fe4p_21+11lev.rap'
  26  4   42   0   0     -1  'Fe 5' './data/fe5va.dat'
   0  0                             './data/gf2604.gam'
                                    './data/gf2604.lin'
                                    './data/fe5p_19+11lev.rap'
  26  5    1   1   0     0   'Fe 6' ' '\n""")

    f.write("  0   0   0   -1   0     0   '    ' ' '")
    f.close()

def makeDirectory(scen:str):
    """
    Create a new directory, and folders therein, to help organize the upcoming TLUSTY and
    SYNSPEC model runs. Also link the data directory and relevant files that change some
    keywords (copied from cool white dwarf test case).
    """
    # Make directories
    if scen in os.listdir('scenarios'):
        ans = input(f'Directory {PATH}/{scen}/ already exists. Would you like to replace it? [y/n]\n')
        if ans.lower()=='n':
            print('Exiting...')
            sys.exit(0)
        elif ans.lower()=='y':
            print("Removing directory...")
            shutil.rmtree(f'scenarios/{scen}')
        else:
            print('Invalid response. Exiting...')
            sys.exit(0)
    os.chdir('scenarios')
    os.mkdir(scen)
    os.chdir(scen)
    os.mkdir('lte')
    os.mkdir('nltec')
    os.mkdir('nltel')
    os.mkdir('synspec')
    os.mkdir('synspec_lte')
    os.chdir(PATH)

    # Link data and white dwarf flag files. Flag files taken from test case 'cwd' -> Hubeny+Lanz(2017a,b,c)
    subprocess.run(['ln','-s','-f',PATH+'/data',PATH+f'/scenarios/{scen}/lte/data'])
    subprocess.run(['ln','-s','-f',PATH+'/data',PATH+f'/scenarios/{scen}/nltec/data'])
    subprocess.run(['ln','-s','-f',PATH+'/data',PATH+f'/scenarios/{scen}/nltel/data'])
    subprocess.run(['ln','-s','-f',PATH+'/data',PATH+f'/scenarios/{scen}/synspec/data'])
    subprocess.run(['ln','-s','-f',PATH+'/data',PATH+f'/scenarios/{scen}/synspec_lte/data'])

    subprocess.run(['ln','-s','-f',PATH+'/wd/'+FLAG,PATH+f'/scenarios/{scen}/lte/cwd2.flag'])
    subprocess.run(['ln','-s','-f',PATH+'/wd/'+FLAG,PATH+f'/scenarios/{scen}/nltec/cwd2.flag'])
    subprocess.run(['ln','-s','-f',PATH+'/wd/'+FLAG,PATH+f'/scenarios/{scen}/nltel/cwd2.flag'])
    subprocess.run(['ln','-s','-f',PATH+'/wd/'+FLAG,PATH+f'/scenarios/{scen}/synspec/cwd2.flag'])
    subprocess.run(['ln','-s','-f',PATH+'/wd/'+FLAG,PATH+f'/scenarios/{scen}/synspec_lte/cwd2.flag'])

def runLTE(scen:str,teff,log_g,species_dict):
    """
    Write input file, run LTE model, and save outputs
    """

    # Writing fort.5
    writeUnit5(LTE,teff,log_g,species_dict,is_lte=True)
    
    # Run LTE model
    print('Running LTE model...')
    os.chdir(LTE)
    try:
        os.system(f"{TLUSTY}/{TLEXE} < {LTE}/fort.5 > {LTE}/fort.6")
    except:
        print("\n Model run has encountered an error. Exiting...")
        sys.exit(0)
    print("LTE model completed!")
    os.chdir(PATH)

def runNLTEC(scen:str,teff,log_g,species_dict):
    """
    
    """

    # Writing fort.5
    writeUnit5(NLTEC,teff,log_g,species_dict,is_lte=True)

    # fetch atmosphere file from LTE run
    os.chdir(NLTEC)
    subprocess.run(['cp',LTE+'/fort.7','fort.8'])
    
    # run nltec model
    print('Running NLTE continuum model...')
    try:
        os.system(f"{TLUSTY}/{TLEXE} < {NLTEC}/fort.5 > {NLTEC}/fort.6")
    except:
        print("\n Model run has encountered an error. Exiting...")
        sys.exit(0)
    print("NLTE continuum model completed!")
    os.chdir(PATH)

def runNLTEL(scen:str,teff,log_g,species_dict):
    """
    
    """

    # Writing fort.5
    writeUnit5(NLTEL,teff,log_g,species_dict,is_lte=True)

    # fetch atmosphere file from NLTE continuum run
    os.chdir(NLTEL)
    subprocess.run(['cp',NLTEC+'/fort.7','fort.8'])
    
    # run nltec model
    print('Running NLTE lines model...')
    try:
        os.system(f"{TLUSTY}/{TLEXE} < {NLTEL}/fort.5 > {NLTEL}/fort.6")
    except:
        print("\n Model run has encountered an error. Exiting...")
        sys.exit(0)
    print("NLTE lines model completed!")
    os.chdir(PATH)

def runSYNSPEC(scen:str,species_dict,lammin:int=900,lammax:int=10000):
    """
    
    """

    # Write input file
    unit5 = """       {1}      50       0
       1       0       0       0
       0       1       1       1       0
       1       1       0       0       0
       2       0       0
    {2}    -{3}      10       0  0.0001    0.1
       0       0"""
    unit5 = unit5.replace('{1}',str(IMODE))
    unit5 = unit5.replace('{2}',str(lammin))
    unit5 = unit5.replace('{3}',str(lammax))
    f = open(SPEC+'/fort.55','w')
    f.write(unit5)
    f.close()
    f = open(SPEC_LTE+'/fort.55','w')
    f.write(unit5)
    f.close()


    # imode determines whether or not we use a linelist
    if IMODE==0:
        subprocess.run(['cp',PATH+'/data/gfATO.dat',SPEC+'/fort.19'])
        subprocess.run(['cp',PATH+'/data/gfATO.dat',SPEC_LTE+'/fort.19'])
        
        # Remove lines for species not present in the model
        elem_ids={
            1: 'h',
            2: 'he',
            3: 'li',
            4: 'be',
            5: 'b',
            6: 'c',
            7: 'n',
            8: 'o',
            9: 'fl',
            10:'ne',
            11:'na',
            12:'mg',
            13:'al',
            14:'si',
            15:'p',
            16:'s',
            17:'cl',
            18:'ar',
            19:'k',
            20:'ca',
            21:'sc',
            22:'ti',
            23:'v',
            24:'cr',
            25:'mg',
            26:'fe',
            27:'co',
            28:'ni'
        }

        f = open(SPEC+'/fort.19','r')
        lines = f.read().split('\n')
        f.close()

        f = open(SPEC+'/fort.19','w')
        for line in lines[:-1]:
            try:
                elem = int(line[13:15])
                if species_dict[elem_ids[elem]]['mode']==2:
                    f.write(line+'\n')
            except KeyError:    # Line associated with an element not yet implemented; ignore line
                continue

    # fetch outputs from NLTE line run
    os.chdir(SPEC)
    subprocess.run(['cp',NLTEL+'/fort.7','fort.8'])
    subprocess.run(['cp',NLTEL+'/fort.5','fort.5'])
    # run SYNSPEC
    print('Running SYNSPEC for the NLTE lines case...')
    try:
        os.system(f'{SYNSPEC}/synspec51.exe < {SPEC}/fort.5 > {SPEC}/fort.6')
    except:
        print("\n Model run has encountered an error. Exiting...")
        sys.exit(0)
    print('SYNSPEC NLTE case complete!')

    # fetch outputs from LTE run
    os.chdir(SPEC_LTE)
    subprocess.run(['cp',LTE+'/fort.7','fort.8'])
    subprocess.run(['cp',LTE+'/fort.5','fort.5'])
    print('Running SYNSPEC for the LTE case...')
    try:
        os.system(f'{SYNSPEC}/synspec51.exe < {SPEC_LTE}/fort.5 > {SPEC_LTE}/fort.6')
    except:
        print("\n Model run has encountered an error. Exiting...")
        sys.exit(0)
    print("SYNSPEC models completed!")
    os.chdir(PATH)

def main():
    # process user inputs
    try:
        scen    = sys.argv[1]
        teff    = float(sys.argv[2])
        log_g   = float(sys.argv[3])
    except IndexError:
        print("Not enough arguments supplied. Call funcion as:\n    % python tlusty.py [name] [t_eff] [log_g]")
        sys.exit(0)

    # Path variables
    os.chdir('tlusty')                           # If ever moving to 208, change this
    global PATH;    PATH    = os.getcwd()
    global TLUSTY;  TLUSTY  = PATH+'/tlusty'
    global SYNSPEC; SYNSPEC = PATH+'/synspec'
    global LTE;     LTE     = PATH+f'/scenarios/{scen}/lte'         # LTE
    global NLTEC;   NLTEC   = PATH+f'/scenarios/{scen}/nltec'       # NLTE, continuum emission
    global NLTEL;   NLTEL   = PATH+f'/scenarios/{scen}/nltel'       # NLTE, lines
    global SPEC;    SPEC    = PATH+f'/scenarios/{scen}/synspec'     # SYNSPEC - NLTE model w/ lines
    global SPEC_LTE;SPEC_LTE= PATH+f'/scenarios/{scen}/synspec_lte' # SYNSPEC - LTE model

    # Other model variables
    global IMODE;   IMODE   = 2;            # SYNSPEC param; 0 --> calculate lines, 2 --> H, He II only
    global FLAG;    FLAG    = 'cwd2.flag'   # name of flag file to copy
    global TLEXE;   TLEXE   = 'tlusty.exe'  # name of TLUSTY executable, allows for changing versions
                                            # tlusty.exe    --> TLUSTY301
                                            # tlusty205.exe --> TLUSTY205
    
    # Dictionary that holds species treatment modes and abundances. No functionality for changing partition functions
    species_dict = {
        'h':    {'mode': 2,'abn': 0.},       # Only hydrogen is on by default
        'he':   {'mode': 0,'abn': 0.},
        'li':   {'mode': 0,'abn': 0.},
        'be':   {'mode': 0,'abn': 0.},
        'b':    {'mode': 0,'abn': 0.},
        'c':    {'mode': 0,'abn': 0.},
        'n':    {'mode': 0,'abn': 0.},
        'o':    {'mode': 0,'abn': 0.},
        'fl':   {'mode': 0,'abn': 0.},
        'ne':   {'mode': 0,'abn': 0.},
        'na':   {'mode': 0,'abn': 0.},
        'mg':   {'mode': 0,'abn': 0.},
        'al':   {'mode': 0,'abn': 0.},
        'si':   {'mode': 0,'abn': 0.},
        'p':    {'mode': 0,'abn': 0.},
        's':    {'mode': 0,'abn': 0.},
        'cl':   {'mode': 0,'abn': 0.},
        'ar':   {'mode': 0,'abn': 0.},
        'k':    {'mode': 0,'abn': 0.},
        'ca':   {'mode': 0,'abn': 0.},
        'sc':   {'mode': 0,'abn': 0.},
        'ti':   {'mode': 0,'abn': 0.},
        'v':    {'mode': 0,'abn': 0.},
        'cr':   {'mode': 0,'abn': 0.},
        'mn':   {'mode': 0,'abn': 0.},
        'fe':   {'mode': 0,'abn': 0.},
        'co':   {'mode': 0,'abn': 0.},
        'ni':   {'mode': 0,'abn': 0.}
    }

    # Check for additional user arguments
    if len(sys.argv) > 4:
        # check for keywords
        for arg in sys.argv[4:]:
            
            key = arg.split('=')[0]
            val = arg.split('=')[1]

            # imode for SYNSPEC
            if key=='imode':
                imode = int(val)
                print(f"Set imode={IMODE}")

            # do He-dominated WD
            if key=='refhe' and bool(val):
                species_dict['h']['mode']=0
                species_dict['h']['abn']=0
                species_dict['he']['mode']=2
                FLAG    = 'cwd.flag'
                # IMODE   = 0
                TLEXE   = 'tlusty205.exe'       # I can only get this to run on TLUSTY205

                # species_dict['he']['abn']=1


            # metal species changes
            if key in species_dict.keys():
                species_dict[key]['mode'] = 2
                if float(val)<0:
                    species_dict[key]['abn'] = 10**float(val)
                else:
                    species_dict[key]['abn'] = float(val)
                IMODE=0

    # Main loop
    makeDirectory(scen)
    runLTE(scen,teff,log_g,species_dict=species_dict)
    runNLTEC(scen,teff,log_g,species_dict=species_dict)
    runNLTEL(scen,teff,log_g,species_dict=species_dict)
    runSYNSPEC(scen,species_dict=species_dict)
    
if __name__ == '__main__':
    main()