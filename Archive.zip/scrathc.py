# NOT LSF PURETLY SCRATCH FILE FOR FUCKING AROUND
from astropy.io import fits
import matplotlib.pyplot as plt
import numpy as np

def doubleModelComp():

    fig,ax = plt.subplots(nrows=3)

    dat1    = np.loadtxt('tlusty/scenarios/test/synspec/fort.7')
    # dat1    = np.loadtxt('tlusty/scenarios/t20000g800/synspec/fort.7')
    dat2    = np.loadtxt('tlusty/grid/hubeny/t20000g800n.spec')
    dat3    = np.loadtxt('tlusty/grid/hubeny2/t200g800n.spec')
    # dat3    = np.loadtxt('tlusty/grid/koester/da20000_800.dk.dat.txt')
    # dat3[:,1] = dat3[:,1]/(4*np.pi)

    ax[2].plot(dat1[:,0],dat1[:,1],label='My run')
    ax[2].plot(dat2[:,0],dat2[:,1],label='Cool metal-rich grid')
    ax[2].plot(dat3[:,0],dat3[:,1],label='Hot pure-H grid')
    ax[2].set_xlim(900,5000)
    ax[2].set_yscale('log')
    ax[2].legend()

    flux1 = np.interp(dat2[:,0],dat1[:,0],dat1[:,1])
    flux2 = np.interp(dat3[:,0],dat1[:,0],dat1[:,1])

    # Axis 1: Lyman series
    ax[0].plot(dat2[:,0],np.abs(1-flux1/dat2[:,1]),label='Model / metal grid')
    ax[0].plot(dat3[:,0],np.abs(1-flux2/dat3[:,1]),label='Model / pure-H grid')

    ax[0].set_yscale('log')
    ax[0].set_xlim(900,1500)
    ax[0].set_ylim(top=1)
    ax[0].hlines(0.01,xmin=900,xmax=1500,colors='black',linestyles='dotted',zorder=-100)
    ax[0].text(1450,0.015,'1%')
    ax[0].set_xlabel(r"Wavelength $\AA$")
    ax[0].set_ylabel("|Model / grid|")
    ax[0].legend()

    # # Axis 2: Balmer series
    ax[1].plot(dat2[:,0],np.abs(1-flux1/dat2[:,1]),label='Model / metal grid')
    ax[1].plot(dat3[:,0],np.abs(1-flux2/dat3[:,1]),label='Model / pure-H grid')

    ax[1].set_yscale('log')
    ax[1].set_xlim(3500,5000)
    ax[1].set_ylim(top=1)
    ax[1].hlines(0.01,xmin=3500,xmax=6000,colors='black',linestyles='dotted',zorder=-100)
    ax[1].text(4800,0.015,'1%')
    ax[1].set_xlabel(r"Wavelength $\AA$")
    ax[1].set_ylabel("|Model / grid|")
    ax[1].legend()

    fig.set_figheight(7)
    plt.tight_layout()
    # plt.savefig('figs/gridcomp_pureh_metal_t20000g800')
    plt.show()

def other():

    dat1    = np.loadtxt('tlusty/scenarios/test/synspec/fort.7')
    dat2    = np.loadtxt('fort.7')
    dat3    = np.loadtxt('tlusty/grid/hubeny2/t200g800n.spec')

    fig,ax = plt.subplots(nrows=2)

    ax[0].plot(dat1[:,0],dat1[:,1],label='SYNSPEC51')
    ax[0].plot(dat2[:,0],dat2[:,1],label='SYNSPEC54')
    ax[0].plot(dat3[:,0],dat3[:,1],label='Ivan\'s Grid')
    # ax[0].plot(dat3[:,0],dat3[:,1],label='Hubeny grid')
    ax[0].set_xscale('log')
    ax[0].set_yscale('log')
    ax[0].set_xlim(right=10000)

    flux51 = np.interp(dat3[:,0],dat1[:,0],dat1[:,1])
    flux54 = np.interp(dat3[:,0],dat2[:,0],dat2[:,1])
    ax[1].plot(dat3[:,0],flux51/dat3[:,1],label="SYNSPEC51 / Ivan")
    ax[1].plot(dat3[:,0],flux54/dat3[:,1],label="SYNSPEC54 / Ivan")
    # ax[1].plot(dat1[:,0],dat1[:,1]/dat3[:,1],label='TLUSTY301 / TLUSTY205')
    ax[1].set_xscale('log')
    # ax[1].set_yscale('log')
    ax[1].set_ylim(0.8,1.2)
    ax[1].set_xlim(right=10000)

    ax[0].legend()
    ax[1].legend()
    plt.show()



fig,ax = plt.subplots()

# dat = np.loadtxt('tlusty/scenarios/test/nltel/fort.14')
# ax.plot(dat[:,0],dat[:,1],label="H")

dat = np.loadtxt('tlusty/scenarios/test_metals/lte/fort.14')
ax.plot(dat[:,0],dat[:,1],label='He')

ax.set_xlim(900,5000)
ax.set_xscale('log')
ax.set_yscale('log')
plt.legend()
plt.show()
input()







dat1    = np.loadtxt('tlusty/scenarios/test/synspec/fort.7')
dat2    = np.loadtxt('fort.7')
dat3    = np.loadtxt('tlusty/grid/hubeny2/t200g800n.spec')

flux51 = np.interp(dat3[:,0],dat1[:,0],dat1[:,1])
flux54 = np.interp(dat3[:,0],dat2[:,0],dat2[:,1])

fig,ax = plt.subplots(nrows=2)

ax[0].plot(dat3[:,0],np.abs(1-flux51/dat3[:,1]),label="SYNSPEC51")
ax[0].plot(dat3[:,0],np.abs(1-flux54/dat3[:,1]),label="SYNSPEC54")

ax[0].set_xlabel(r"Wavelength [$\AA$]")
# ax[0].set_xlim(900,1500)
ax[0].set_ylabel(r"| Model / Grid |")
ax[0].set_yscale('log')
ax[0].set_xlim(900,5000)
ax[0].set_ylim(1e-4,0.1)
ax[0].legend()
# ax[0].hlines(y=0.01,xmin=900,xmax=1500,colors='black',linestyles='dashed')

ax[1].plot(dat3[:,0],flux51,label="SYNSPEC51")
ax[1].plot(dat3[:,0],flux54,label="SYNSPEC54")
ax[1].plot(dat3[:,0],dat3[:,1],label="Ivan")

ax[1].set_xlabel(r"Wavelength [$\AA$]")
ax[1].set_xlim(900,5000)
ax[1].set_ylabel(r"| Model / Grid |")
ax[1].set_yscale('log')
# ax[1].set_ylim(1e-4,0.1)
ax[1].legend()
# ax[1].hlines(y=0.01,xmin=3500,xmax=5000,colors='black',linestyles='dashed')

plt.tight_layout()
# plt.savefig('temp',dpi=250)
plt.show()
plt.close()
