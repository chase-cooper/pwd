from astroquery.gaia import Gaia
from astroquery.mast import Catalogs
from astroquery.mast import Mast
from astroquery.simbad import Simbad
import numpy as np

# ### Given an name/id, fetch fluxes in SIMBAD
# Simbad.add_votable_fields('allfluxes','mesplx')
# name = 'Gaia DR3 3105360521513256832'
# s   = Simbad.query_object(name)

# # Parallax; currently taking the average, and propogating uncertainties
# plx     = np.average(s['mesplx.plx'][:])                    # [mas]
# err     = np.sqrt(np.sum(np.square(s['mesplx.plx_err'])))   # [mas]
# dist    = 1000/plx                                          # [pc]
# dist_err= [dist-1000/(plx+err),dist-1000/(plx-err)]         # [pc]
# print(plx,err)
# print(dist,dist_err)

# # Get GAIA DR3 G val
# G   = s['G'][0]

# # Check for ugriz AB magnitudes
# u   = s['u'][0]
# g   = s['g'][0]
# r   = s['r'][0]
# i   = s['i'][0]
# z   = s['z'][0]

### GAIA
ids = '[]'

job = Gaia.launch_job_async("SELECT TOP 100 source_id, parallax, parallax_error, phot_g_mean_mag, phot_bp_mean_mag, phot_rp_mean_mag "
                            "from gaiadr3.gaia_source where source_id = 3105360521513256832 order by source_id",
                            dump_to_file=True, output_format='votable')
res = job.get_results()

# Table values
# note: mags are in Vega system
plx     = res['parallax'][0]
plx_err = res['parallax_error'][0]
bp_mag  = res['phot_bp_mean_mag'][0]
g_mag   = res['phot_g_mean_mag'][0]
rp_mag  = res['phot_rp_mean_mag'][0]

# Derived values
dist    = 1000/plx
dist_err= [dist-1000/(plx+plx_err),dist-1000/(plx-plx_err)]
# also want fluxes, flux errors

print(plx,plx_err,bp_mag,g_mag,rp_mag)
input()
